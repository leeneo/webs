/*
	{
		"author":"Leeneo/leeneo.cn",
		"version":,"1.0"
  }
*/
window.onload = function () {

    // bgn_menu下拉列表隐藏显示动效脚本
    var btn_menu = document.getElementById('btn_menu');
    var menu_nav = document.getElementById('menu_nav');
    var menu_container = document.getElementById('menu_container');

    // menu_container.onclick = function () {
    //     menu_nav.style.display = 'block';
    //     menu_nav.style.top = '29px';
    // }
    // menu_container.onmouseenter = function () {
    //     menu_nav.style.display = 'block';
    //     menu_nav.style.top = '29px';
    // }
    menu_container.onmouseleave = function () {
        menu_nav.style.display = 'none';
        blkey=true;
    }

    var blkey = true;

    $(btn_menu).click(function () {
        if (blkey == true) {
            $(this).siblings().slideDown(500);
        } else {
            $(this).siblings().hide();
        }
        blkey = !blkey;
    });

    // 适配移动端事件
    // $(btn_menu).on('touchstart',function () {
    //     $(this).siblings().slideDown(1000);
    // });
    // $(btn_menu).on('touchend', function () {
    //     $(this).siblings().hide(2000);
    // });

    // $('#btn_menu').on('touchstart', function () {
    //     console.log('touchstart')
    // });
    // $('#btn_menu').on('touchend', function () {
    //     console.log('touchend')        
    //     $('#menu_nav').css('display','none');
    // });
}