// 滚动鼠标，切屏效果
$aryLi = $('.bkg_container >li');
$rolDot = $('aside >div >span');
var inx = $rolDot.index();

document.body.onmousewheel = function (e) {
    e = event || window.event;
    // console.log(event);	
    // console.log(event.deltaY);
    var blWheel = event.deltaY;

    if (blWheel == -150) {
        //向上滚动
        inx--;
        fnDisbkg();

    } else if (blWheel == 150) {
        //向下滚动
        inx++;
        fnDisbkg();        
        
    } else {     
        console.log('判断滚轮滚动方向失败');
    }

    // console.log(inx);
    function fnDisbkg() {
        // $aryLi.eq(inx).css({
        //     'transition': 'all .5s ease 0'
        // })
        // $aryLi.eq(inx).addClass('act').siblings().removeClass('act');
        $aryLi.eq(inx).stop().fadeIn(1500).siblings().stop().fadeOut(1500);
        $rolDot.eq(inx).addClass('rolbkg').siblings().removeClass('rolbkg');
    }
};