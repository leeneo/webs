/*
	添加移动端滑屏切换效果
	{
		"author":"Leeneo/leeneo.cn",
		"version":,"1.0"
  }
*/
$(function () {

	$aLi = $('article >.slide_screen >li');
	var iH = $(window).height();
	var strartY, moveY, endY, nowIndex, nextIndex;

	// 由于我把li的z-index属性都设为-1 以下的值了，所以li无法触发事件
	// $aLi.on('touchstart', startFn);
	// alert($aLi.length);

	$(window).on('touchstart', startFn);

	// $(document).on( 'touchstart',startFn);
	// function fnClck(ev) {
	// 	alert('事件绑定');
	// }

	function startFn(ev) {

		// alert($aLi.index());
		//nowIndex这个值很关键，图片能不能正常切换，完全取决于这个值
		nowIndex = $aLi.index();
		strartY = ev.originalEvent.changedTouches[0].clientY;

		$(this).on('touchmove', moveFn);

		$(this).on('touchend', endFn);

	}

	function moveFn(ev) {
		endY = ev.originalEvent.changedTouches[0].clientY;

		if (strartY > endY) {

			nextIndex = nowIndex + 1;
			if (nextIndex == 3) {
				nextIndex = 0
			}

			$aLi.eq(nextIndex).show();
			$aLi.eq(nextIndex).stop().addClass('act').siblings().removeClass('act');

			moveY = strartY - endY;
			$aLi.eq(nextIndex).css('top', iH - moveY);

			console.log(nextIndex);

		} else if (strartY < endY) {
			nextIndex = nowIndex - 1;
			if (nextIndex == -1) {
				nextIndex = 2
			}

			$aLi.eq(nextIndex).show();
			$aLi.eq(nextIndex).addClass('act').siblings().removeClass('act');

			moveY = endY - strartY;
			$aLi.eq(nextIndex).css('top', -iH + moveY);
			console.log(-iH + moveY);
		}

	}

	function endFn(ev) {
		$aLi.eq(nextIndex).css('top', 0);
		$aLi.eq(nextIndex).css({
			'transition': 'all .5s'
		})
		endY = ev.originalEvent.changedTouches[0].clientY;

		if (endY != strartY) {
			$aLi.off('touchmove touchstart touchend');
		}

	}

	$aLi.on('transitionend', function () {
		$aLi.eq(nextIndex).css({
			'transition': ''
		})
		$aLi.eq(nextIndex).show().siblings().hide();

		$aLi.on('touchstart', startFn);

	});

})