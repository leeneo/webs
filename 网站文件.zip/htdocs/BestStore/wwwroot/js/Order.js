﻿function OnSubmitOrder() {
    var address = $("#dpShipAddress").val();
    $("#addressCtrl").val(address);
}
